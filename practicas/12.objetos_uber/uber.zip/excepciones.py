class CoordenadasError(Exception):
    pass